# app/__init__.py
# Mantido vazio para indicar que "app" é um pacote Python.
